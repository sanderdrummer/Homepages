<?php

class DatabaseSeeder extends Seeder {

	/**
	 * Run the database seeds.
	 *
	 * @return void
	 */
	public function run()
	{
		Eloquent::unguard();

		// $this->call('UserTableSeeder');
		$this->call('MyAppSeeder');

	}

}

class MyAppSeeder extends Seeder {

	public function run(){
		DB::table('Players')->delete();
		DB::table('Questions')->delete();
		DB::table('Questionnaires')->delete();
		DB::table('Answers')->delete();
		DB::table('Level')->delete();

		$eingang = Questionnaire::create(array('name' => 'eingang'));
		$mittel = Questionnaire::create(array('name' => 'mittel'));
		$end = Questionnaire::create(array('name' => 'end'));
		$test = Questionnaire::create(array('name' => 'test'));

		$level = Level::create(array('score' => 1,'mistakes' => 10,'hits' => 2,'info' => 'info'));
		
		$test1 = Question::create(array('question' => '1','questionnaire_id' => $test->id));  
		$test2 = Question::create(array('question' => '2','questionnaire_id' => $test->id));  
		$test3 = Question::create(array('question' => '3','questionnaire_id' => $test->id));  
		$test4 = Question::create(array('question' => '4','questionnaire_id' => $test->id));  
		
		$eingang1 = Question::create(array('question' => 'Ich spiele häufig Computerspiele','questionnaire_id' => $eingang->id));  
		$eingang1 = Question::create(array('question' => 'Ich kenne die Gestaltgesetze','questionnaire_id' => $eingang->id));  
		$fam1 = Question::create(array('question' => 'Ich mag solche Aufgaben und Inhalte','questionnaire_id' => $eingang->id));  
		$fam2 = Question::create(array('question' => 'Ich glaube, der Schwierigkeit dieses Spiels gewachsen zu sein','questionnaire_id' => $eingang->id));  
		$fam3 = Question::create(array('question' => 'Wahrscheinlich werde ich das Spiel nicht schaffen','questionnaire_id' => $eingang->id));  
		$fam4 = Question::create(array('question' => 'Bei dem Spiel mag ich die Rolle des Spielers, der Zusammenhänge entdeckt','questionnaire_id' => $eingang->id));  
		$fam5 = Question::create(array('question' => 'Ich fühle mich unter Druck bei dem Spiel gut abschneiden zu müssen','questionnaire_id' => $eingang->id));  
		$fam6 = Question::create(array('question' => 'Das Spiel ist eine richtige Herausforderung für mich','questionnaire_id' => $eingang->id));  
		$fam7 = Question::create(array('question' => 'Nach dem Lesen der Instruktion erscheint mir das Spiel sehr interessant','questionnaire_id' => $eingang->id));  
		$fam8 = Question::create(array('question' => 'Ich bin sehr gespannt darauf, wie gut ich hier abschneiden werde','questionnaire_id' => $eingang->id));  
		$fam9 = Question::create(array('question' => 'Ich fürchte mich ein wenig davor, dass ich mich hier blamieren könnte','questionnaire_id' => $eingang->id));  
		$fam10 = Question::create(array('question' => 'Ich bin fest entschlossen, mich bei diesem Spiel voll anzustrengen','questionnaire_id' => $eingang->id));  
		$fam11 = Question::create(array('question' => 'Bei Spielen wie diesem brauche ich keine Belohnung, sie machen mir auch so viel Spaß','questionnaire_id' => $eingang->id));  
		$fam12 = Question::create(array('question' => 'Es ist mir etwas peinlich, hier zu versagen','questionnaire_id' => $eingang->id));  
		$fam13 = Question::create(array('question' => 'Ich glaube, dass kann jeder schaffen','questionnaire_id' => $eingang->id));  
		$fam14 = Question::create(array('question' => 'Ich glaube, ich schaffe dieses Spiel nicht','questionnaire_id' => $eingang->id));  
		$fam15 = Question::create(array('question' => 'Wenn ich das Spiel schaffe, werde ich schon ein wenig stolz auf meine Tüchtigkeit sein','questionnaire_id' => $eingang->id));  
		$fam16 = Question::create(array('question' => 'Wenn ich an das Spiel denke, bin ich etwas beunruhigt','questionnaire_id' => $eingang->id));  
		$fam17 = Question::create(array('question' => 'Eine solches Spiel würde ich auch in meiner Freizeit spielen','questionnaire_id' => $eingang->id));  
		$fam18 = Question::create(array('question' => 'Die konkreten Leistungsanforderungen hier lähmen mich','questionnaire_id' => $eingang->id));  
 
		$famkm1 = Question::create(array('question' => 'Das Spiel macht mir noch Spass','questionnaire_id' => $mittel->id));  
		$famkm2 = Question::create(array('question' => 'Ich bin sicher, die richige Lösung zu finden','questionnaire_id' => $mittel->id));  
		$famkm3 = Question::create(array('question' => 'Mir ist klar, wie ich weiter vorgehen soll','questionnaire_id' => $mittel->id));  
	
		$famke1 = Question::create(array('question' => 'Das Spiel macht mir noch Spass','questionnaire_id' => $end->id));  
		$famke2 = Question::create(array('question' => 'Ich bin sicher, die richige Lösung zu finden','questionnaire_id' => $end->id));  
		$famke3 = Question::create(array('question' => 'Mir ist klar, wie ich weiter vorgehen soll','questionnaire_id' => $end->id));  
	}
}