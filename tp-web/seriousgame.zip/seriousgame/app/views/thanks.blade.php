@extends('layout')

@section('content')

	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<h1>Vielen Dank für deine Teilnahme</h1>
				<h2>Bitte notiere noch deine ID auf der Einverständniserklärung</h2>
				<h3>ID: {{$player}}</h3>
			</div>
		</div>
	
	</div>
@stop