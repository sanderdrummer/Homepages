@extends('layout')

@section('content')

	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<h1>Willkommen im Verwaltungsbereich</h1>
				<h2>Konfiguriere deinen Fragebogen oder Werte neue Ergebnisse aus!</h2>
				<hr>
			</div>
			<div class="col-xs-5"><a href="adminstart/admin"><h2>Fragebögen Verwalten</h2></a></div>
			<div class="col-xs-5"><a href="adminstart/results"><h2>Ergebnisse Betrachten</h2> </a></div>
		</div>
	</div>
@stop

