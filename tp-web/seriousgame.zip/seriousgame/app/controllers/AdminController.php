<?php

class AdminController extends BaseController {


	//Startscreen
	public function adminstart()
	{
		return View::make('adminstart');
	}	

	//Zeige Fragebogen
	public function admin()
	{
		$quests = Questionnaire::all();
		$quest = Questionnaire::all()->first();
		$questions = Question::where('questionnaire_id', '=', $quest->id)->get();
		return View::make('admin2', array('quests' => $quests, 'quest' => $quest, 'questions' => $questions));
	}	

	//Wechsele Fragebogen
	public function changeQuestionnaire()
	{
		$quests = Questionnaire::all();
		$select = Input::get('selection');
		$quest = Questionnaire::where('name', '=', $select)->first();
		$questions = Question::where('questionnaire_id', '=', $quest->id)->get();
		return View::make('admin2', array('quests' => $quests, 'quest' => $quest, 'questions' => $questions));
	}	

	//Neue frage zu aktuellem Fragebogen hinzufuegen
	public function newQuestion()
	{
		
		$qid = Input::get("qid");
		$quest =  Questionnaire::where('id', '=', $qid)->first();
		$newQuestion = new Question;
		$newQuestion->question = Input::get('neueFrage');
		$newQuestion->questionnaire_id = $qid;
		$newQuestion->save();

		$toanswer = Question::all();
		return Redirect::to('adminstart/admin');
	}

	//Vorhandene Fragen editieren
	public function modifyQuestion()
	{
		$qid = Input::get("qid");
		$questions = Question::where('questionnaire_id', '=', $qid)->get();
		foreach ($questions as $q) {
			$q->questionnaire_id = $qid;
			$fieldname = "field".$q->id;
			$q->question =Input::get($fieldname);
			$q->save();
			if(($q->question) == "x"){
				$q->delete();
			}
		}
		$questions = Question::where('questionnaire_id', '=', $qid)->get();
		return Redirect::to('adminstart/admin');
	}

	//Ergebnisse Anzeigen
	public function results(){

		$players = Player::all();
		$answers = Answer::all();
		$questions = Question::all();
		return View::make('results', array('players' => $players, 'answers' => $answers, 'questions' => $questions));
	}
	//Alternative Ansicht der Ergebnisse
	public function resultsOnly(){
		$answers = Answer::all();
		$questions = Question::all();
		return View::make('resultsonly', array('answers' => $answers, 'questions' => $questions));
	}	

	//Zeige aktuelle Verteilung der Porbandentypen in den Testgruppen
	public function statistics(){

		$counts = [
			"negativ" => Player::where('gametype','=', 'negativ')->count(),
			"positiv" => Player::where('gametype','=', 'positiv')->count(),
			"neutral" => Player::where('gametype','=', 'neutral')->count()
		];
			echo "Anzahl aktuell: n " . $counts["negativ"] . ' p ' . $counts["positiv"] ." neutral " . $counts['neutral'] . '<br>'
			."<br>"."Anzahl 1: " .' negativ '. Player::where('gametype','=', 'negativ')->where('type','=',"1")->count().' neutral '.  Player::where('gametype','=', 'neutral')->where('type','=',"1")->count() .' positiv '. Player::where('gametype','=', 'positiv')->where('type','=',"1")->count() 
			."<br>"."Anzahl 2: " .' negativ '. Player::where('gametype','=', 'negativ')->where('type','=',"2")->count().' neutral '.  Player::where('gametype','=', 'neutral')->where('type','=',"2")->count() .' positiv '. Player::where('gametype','=', 'positiv')->where('type','=',"2")->count() 
			."<br>"."Anzahl 3: " .' negativ '. Player::where('gametype','=', 'negativ')->where('type','=',"3")->count().' neutral '.  Player::where('gametype','=', 'neutral')->where('type','=',"3")->count() .' positiv '. Player::where('gametype','=', 'positiv')->where('type','=',"3")->count() 
			."<br>"."Anzahl 4: " .' negativ '. Player::where('gametype','=', 'negativ')->where('type','=',"4")->count().' neutral '.  Player::where('gametype','=', 'neutral')->where('type','=',"4")->count() .' positiv '. Player::where('gametype','=', 'positiv')->where('type','=',"4")->count() 
			."<br>"."Anzahl 5: " .' negativ '. Player::where('gametype','=', 'negativ')->where('type','=',"5")->count().' neutral '.  Player::where('gametype','=', 'neutral')->where('type','=',"5")->count() .' positiv '. Player::where('gametype','=', 'positiv')->where('type','=',"5")->count() 
			."<br>"."Anzahl 6: " .' negativ '. Player::where('gametype','=', 'negativ')->where('type','=',"6")->count().' neutral '.  Player::where('gametype','=', 'neutral')->where('type','=',"6")->count() .' positiv '. Player::where('gametype','=', 'positiv')->where('type','=',"6")->count() 
			."<br>"."Anzahl 7: " .' negativ '. Player::where('gametype','=', 'negativ')->where('type','=',"7")->count().' neutral '.  Player::where('gametype','=', 'neutral')->where('type','=',"7")->count() .' positiv '. Player::where('gametype','=', 'positiv')->where('type','=',"7")->count() 
			."<br>"."Anzahl 8: " .' negativ '. Player::where('gametype','=', 'negativ')->where('type','=',"8")->count().' neutral '.  Player::where('gametype','=', 'neutral')->where('type','=',"8")->count() .' positiv '. Player::where('gametype','=', 'positiv')->where('type','=',"8")->count() 
			
			 ;
	}


}
