<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
*/

Route::get('/', 'HomeController@start');
Route::get('/player','HomeController@createplayer');

Route::post('/player/data','HomeController@writedata');
Route::post('/player/midquestions', 'HomeController@midquestions');
Route::post('/player/midquestions/done', 'HomeController@midquestionsdone');
Route::post('/player/end', 'HomeController@end');
Route::post('/player/end/done', 'HomeController@enddone');
Route::post('/player/end/test', 'HomeController@endtest');
Route::post('/player/end/test/done', 'HomeController@endtestdone');

Route::get('/adminstart', 'AdminController@adminstart');
Route::get('/adminstart/statistics', 'AdminController@statistics');
Route::get('adminstart/results', 'AdminController@results');
Route::get('adminstart/results/only', 'AdminController@resultsOnly');
Route::get('adminstart/showQuestions', 'AdminController@showQuestions');
Route::post('adminstart/changeQuestionnaire', 'AdminController@changeQuestionnaire');
Route::get('adminstart/admin/newQuestion', 'AdminController@newQuestion');
Route::get('adminstart/admin/modifyQuestion', 'AdminController@modifyQuestion');





