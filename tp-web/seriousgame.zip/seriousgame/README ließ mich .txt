Struktur (Wo ist was):

	Serious Game Daten:
		Code:			public/src
		Assets: 		public/assets
		Frameworks:		public/lib
	Serverdaten:
		Controller: 	app/controllers
		Models:			app/models
		Views:			app/views
		Routes:			app/
		DB Schema:		app/database/migrations
		DB Init Script:	app/database/seeds
		Config Files:	app/config

Setup:
Voraussetzungen: Webserver mit Php > 5.3 und Datenbank(sqlite,mysql,pgsql,sqlsrv)

1. Datenbankverbindung herstellen: Zugangsdaten in app/config/database.php eintragen

2. Datenbank mit php artisan initialisieren.
	2.1 Konsole im seriousgame Verzeichnis öffnen
	2.2 php artisan migrate  ausführen
	2.3 php artisan db:seed  ausführen 
3. Serious Game über serverhost/public starten
4. Verwaltungsoberfläche über serverhost/public/adminstart starten

5. Viel Spass :)

