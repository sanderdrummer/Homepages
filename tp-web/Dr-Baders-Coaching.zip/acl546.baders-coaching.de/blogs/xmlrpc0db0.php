<?xml version="1.0" encoding="UTF-8"?><rsd version="1.0" xmlns="http://archipelago.phrasewise.com/rsd">
  <service>
    <engineName>WordPress</engineName>
    <engineLink>http://wordpress.org/</engineLink>
    <homePageLink>http://acl546.baders-coaching.de/blogs</homePageLink>
    <apis>
      <api name="WordPress" blogID="1" preferred="true" apiLink="http://acl546.baders-coaching.de/blogs/xmlrpc.php" />
      <api name="Movable Type" blogID="1" preferred="false" apiLink="http://acl546.baders-coaching.de/blogs/xmlrpc.php" />
      <api name="MetaWeblog" blogID="1" preferred="false" apiLink="http://acl546.baders-coaching.de/blogs/xmlrpc.php" />
      <api name="Blogger" blogID="1" preferred="false" apiLink="http://acl546.baders-coaching.de/blogs/xmlrpc.php" />
          </apis>
  </service>
</rsd>
